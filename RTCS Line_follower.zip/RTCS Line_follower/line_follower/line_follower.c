//======================================================================
//
// Test program to test the infrared sensors (and motors) of the
// 4tronix initio robot car. One can run this program within an
// ssh session.
//
// author: Raimund Kirner, University of Hertfordshire
//         initial version: Oct.2016
//
// license: GNU LESSER GENERAL PUBLIC LICENSE
//          Version 2.1, February 1999
//
// Compilation: 
// gcc -o line_follower -Wall -Werror -lcurses -lwiringPi -lpthread -linitio line_follower.c
//
//======================================================================

#include <stdlib.h>
#include <initio.h>
#include <curses.h>

// IMPORTANT: adjust WHITE() based on your car’s configuration.
// For most Initio models: 0 = white, 1 = black
#define WHITE(a) ((a)==0)
//#define WHITE(a) ((a)!=0)   // Enable this line for inverted sensors

#define BLACK(a) (!WHITE(a))

#define forwardSpeed 87   // forward drive speed
#define turnSpeed    100  // spinning speed


//======================================================================
// line_follower():
// Simple line-following program using IR line sensors.
//======================================================================
void line_follower(int argc, char *argv[]) 
{
    int ch = 0;
    int irL, irR;   // obstacle IR sensors
    int lfL, lfR;   // line sensors
    int lastDirection = 0;  // -1 = left, +1 = right, 0 = straight

    mvprintw(1, 1, "%s: Press 'q' to end program", argv[0]);
    initio_DriveForward(forwardSpeed);  // start moving forward

    while (ch != 'q') {

        // --- Read sensors ---
        irL = initio_IrLeft();
        irR = initio_IrRight();
        lfL = initio_IrLineLeft();
        lfR = initio_IrLineRight();

        // --- OBSTACLE DETECTED ---
        if (irL != 0 || irR != 0) {
            mvprintw(3, 1, "Action 1: Stop (Obstacle: %d, %d)        ", irL, irR);
            initio_DriveForward(0);
        }

        // --- BOTH SENSORS ON BLACK (ON TRACK) ---
        else if (BLACK(lfL) && BLACK(lfR)) {
            mvprintw(3, 1, "Action 2: Straight (Line: %d, %d)       ", lfL, lfR);
            initio_DriveForward(forwardSpeed);
            lastDirection = 0;
        }

        // --- LEFT BLACK, RIGHT WHITE = TOO FAR RIGHT -> SPIN LEFT ---
        else if (BLACK(lfL) && WHITE(lfR)) {
            mvprintw(3, 1, "Action 3: Spin Left (Line: %d, %d)      ", lfL, lfR);
            initio_SpinLeft(turnSpeed);
            lastDirection = -1;
        }

        // --- LEFT WHITE, RIGHT BLACK = TOO FAR LEFT -> SPIN RIGHT ---
        else if (WHITE(lfL) && BLACK(lfR)) {
            mvprintw(3, 1, "Action 4: Spin Right (Line: %d, %d)     ", lfL, lfR);
            initio_SpinRight(turnSpeed);
            lastDirection = +1;
        }

        // --- LOST LINE ---
        else {
            mvprintw(3, 1, "Lost line! (Line: %d, %d)               ", lfL, lfR);

            // Try to find the line by spinning in the last known direction
            if (lastDirection < 0) {
                initio_SpinLeft(turnSpeed);
            }
            else if (lastDirection > 0) {
                initio_SpinRight(turnSpeed);
            }
            else {
                initio_DriveForward(0); // no idea -> stop
            }
        }

        // detect key presses
        ch = getch();
        if (ch != ERR)
            mvprintw(2, 1, "Key code: '%c' (%d)         ", ch, ch);

        refresh();
    }

    initio_DriveForward(0);  // safe stop
    return;
}


//======================================================================
// main(): initialisation
//======================================================================
int main(int argc, char *argv[])
{
    WINDOW *mainwin = initscr();
    noecho();
    cbreak();
    nodelay(mainwin, TRUE);
    keypad(mainwin, TRUE);

    initio_Init();
    line_follower(argc, argv);
    initio_Cleanup();
    endwin();

    return EXIT_SUCCESS;
}

